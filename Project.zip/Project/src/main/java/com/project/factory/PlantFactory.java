package com.project.factory;

import com.project.modules.*;
import com.project.logger.Logger;

import java.util.List;

/**
 * Factory class responsible for creating instances of Plant subclasses based on PlantType.
 */
public class PlantFactory {

    /**
     * Creates and returns an instance of a Plant subclass based on the provided PlantType.
     *
     * @param type                   The type of plant to create.
     * @param name                   The name of the plant.
     * @param waterRequirement       The water requirement of the plant.
     * @param pestVulnerabilities    A list of pests that can attack the plant.
     * @param temperatureToleranceLow  The lower bound of temperature tolerance.
     * @param temperatureToleranceHigh The upper bound of temperature tolerance.
     * @param additionalParams       Additional parameters specific to the plant type.
     * @return An instance of a Plant subclass.
     * @throws IllegalArgumentException if the PlantType is unsupported or parameters are invalid.
     */
    public static Plant createPlant(
            PlantType type,
            String name,
            int waterRequirement,
            List<String> pestVulnerabilities,
            int temperatureToleranceLow,
            int temperatureToleranceHigh,
            Object... additionalParams
    ) {
        switch (type) {
            case MANGO:
                if (additionalParams.length < 1) {
                    throw new IllegalArgumentException("Mango requires fruitYield parameter.");
                }
                int fruitYield;
                try {
                    fruitYield = (Integer) additionalParams[0];
                } catch (ClassCastException e) {
                    throw new IllegalArgumentException("Invalid parameters for Mango. Expected integer for fruitYield.");
                }
                return new Mango(
                        name,
                        waterRequirement,
                        pestVulnerabilities,
                        temperatureToleranceLow,
                        temperatureToleranceHigh,
                        200,    // initialHeight in cm (can be parameterized if needed)
                        10,     // growthRate in cm/day (can be parameterized if needed)
                        fruitYield
                );

            case ASHOKA:
                if (additionalParams.length < 1) {
                    throw new IllegalArgumentException("Ashoka requires floweringSeason parameter.");
                }
                String floweringSeason;
                try {
                    floweringSeason = (String) additionalParams[0];
                } catch (ClassCastException e) {
                    throw new IllegalArgumentException("Invalid parameters for Ashoka. Expected String for floweringSeason.");
                }
                return new Ashoka(
                        name,
                        waterRequirement,
                        pestVulnerabilities,
                        temperatureToleranceLow,
                        temperatureToleranceHigh,
                        150,               // initialHeight in cm (can be parameterized if needed)
                        8,                 // growthRate in cm/day (can be parameterized if needed)
                        floweringSeason
                );

            case ROSE:
                if (additionalParams.length < 1) {
                    throw new IllegalArgumentException("Rose requires fragrance parameter.");
                }
                String fragrance;
                try {
                    fragrance = (String) additionalParams[0];
                } catch (ClassCastException e) {
                    throw new IllegalArgumentException("Invalid parameters for Rose. Expected String for fragrance.");
                }
                return new Rose(
                        name,
                        waterRequirement,
                        pestVulnerabilities,
                        temperatureToleranceLow,
                        temperatureToleranceHigh,
                        20,                // initialDensity (can be parameterized if needed)
                        30,                // trimmingFrequency in days (can be parameterized if needed)
                        fragrance
                );

            case SUNFLOWER:
                if (additionalParams.length < 1) {
                    throw new IllegalArgumentException("Sunflower requires seedProduction parameter.");
                }
                int seedProduction;
                try {
                    seedProduction = (Integer) additionalParams[0];
                } catch (ClassCastException e) {
                    throw new IllegalArgumentException("Invalid parameters for Sunflower. Expected integer for seedProduction.");
                }
                return new Sunflower(
                        name,
                        waterRequirement,
                        pestVulnerabilities,
                        temperatureToleranceLow,
                        temperatureToleranceHigh,
                        15,                // initialDensity (can be parameterized if needed)
                        25,                // trimmingFrequency in days (can be parameterized if needed)
                        seedProduction
                );

            case TULSI:
                if (additionalParams.length < 1) {
                    throw new IllegalArgumentException("Tulsi requires medicinalProperties parameter.");
                }
                String medicinalProperties;
                try {
                    medicinalProperties = (String) additionalParams[0];
                } catch (ClassCastException e) {
                    throw new IllegalArgumentException("Invalid parameters for Tulsi. Expected String for medicinalProperties.");
                }
                return new Tulsi(
                        name,
                        waterRequirement,
                        pestVulnerabilities,
                        temperatureToleranceLow,
                        temperatureToleranceHigh,
                        10,                // initialDensity (can be parameterized if needed)
                        20,                // trimmingFrequency in days (can be parameterized if needed)
                        medicinalProperties
                );

            case TREE:
                if (additionalParams.length < 2) {
                    throw new IllegalArgumentException("Tree requires initialHeight and growthRate parameters.");
                }
                int initialHeight;
                int growthRate;
                try {
                    initialHeight = (Integer) additionalParams[0];
                    growthRate = (Integer) additionalParams[1];
                } catch (ClassCastException e) {
                    throw new IllegalArgumentException("Invalid parameters for Tree. Expected integers for initialHeight and growthRate.");
                }
                return new Tree(
                        name,
                        waterRequirement,
                        pestVulnerabilities,
                        temperatureToleranceLow,
                        temperatureToleranceHigh,
                        initialHeight,
                        growthRate
                );

            case BUSH:
                if (additionalParams.length < 2) {
                    throw new IllegalArgumentException("Bush requires initialDensity and trimmingFrequency parameters.");
                }
                int initialDensity;
                int trimmingFrequency;
                try {
                    initialDensity = (Integer) additionalParams[0];
                    trimmingFrequency = (Integer) additionalParams[1];
                } catch (ClassCastException e) {
                    throw new IllegalArgumentException("Invalid parameters for Bush. Expected integers for initialDensity and trimmingFrequency.");
                }
                return new Bush(
                        name,
                        waterRequirement,
                        pestVulnerabilities,
                        temperatureToleranceLow,
                        temperatureToleranceHigh,
                        initialDensity,
                        trimmingFrequency
                );

            default:
                Logger.log(Logger.LogLevel.ERROR, "Unsupported PlantType: " + type);
                throw new IllegalArgumentException("Unsupported PlantType: " + type);
        }
    }
}
