package com.project.factory;

public enum PlantType {
    TREE,
    BUSH,
    FLOWER,
    MANGO,
    ASHOKA,
    ROSE,
    SUNFLOWER,
    TULSI
    // Add more plant types here as needed, e.g., FLOWER, CACTUS, etc.
}
